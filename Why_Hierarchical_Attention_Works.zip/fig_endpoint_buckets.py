"""fig_endpoint_buckets.py

Endpoint bucket-count diagnostic (Process A sampling).

Index convention (matches the revised paper):
  A history is x = (x_0, ..., x_{T-1}). Python negative indices follow
  x[-d] == x_{T-d}.

Outputs:
  - fig_endpoint_buckets.pdf
  - fig_endpoint_buckets.png
"""

import numpy as np
import matplotlib.pyplot as plt


# Sentinel for missing anchors (corresponds to \bot in the paper).
# Histories take values in {0,1}, so BOT=-1 is outside the token alphabet.
BOT = -1


# ----------------------------- Endpoints -----------------------------

def end_local_window(x: np.ndarray, w: int):
    """Local window endpoint: (x_{T-w}, ..., x_{T-1}) with truncation."""
    w_eff = min(len(x), w)
    return tuple(x[-w_eff:].tolist())


def end_local_plus_exp_anchors(x: np.ndarray, w: int, K: int):
    """Local window + exponentially spaced anchors x_{T-w*2^j}, j=0..K-1."""
    e = [end_local_window(x, w)]
    for j in range(K):
        d = w * (2**j)
        e.append(int(x[-d]) if len(x) >= d else BOT)
    return tuple(e)


def end_local_plus_multiscale_parities(x: np.ndarray, w: int, K: int):
    """Local window + parities of suffix blocks of size w*2^j, j=0..K-1."""
    e = [end_local_window(x, w)]
    for j in range(K):
        s = w * (2**j)
        m = min(len(x), s)
        parity = int(np.sum(x[-m:]) % 2)
        e.append(parity)
    return tuple(e)


# ----------------------------- Bucket Counting ------------------------

def count_buckets(endpoint_fn, T: int, n_hist: int, seed: int) -> int:
    rng = np.random.default_rng(seed)
    X = rng.integers(0, 2, size=(n_hist, T), dtype=np.int8)
    buckets = set()
    for i in range(n_hist):
        buckets.add(endpoint_fn(X[i]))
    return len(buckets)


# ----------------------------- Main ----------------------------------

def main():
    # Parameters (kept consistent across scripts)
    T = 256
    n_hist = 20000
    w = 16
    Ks = list(range(0, 7))  # refinement depth

    bins_exp, bins_par = [], []
    for K in Ks:
        bins_exp.append(
            count_buckets(
                endpoint_fn=lambda x, w=w, K=K: end_local_plus_exp_anchors(x, w, K),
                T=T,
                n_hist=n_hist,
                seed=500 + K,
            )
        )
        bins_par.append(
            count_buckets(
                endpoint_fn=lambda x, w=w, K=K: end_local_plus_multiscale_parities(x, w, K),
                T=T,
                n_hist=n_hist,
                seed=600 + K,
            )
        )

    fig = plt.figure()
    plt.plot(Ks, bins_exp, marker="o", label="Buckets: exponential anchors")
    plt.plot(Ks, bins_par, marker="o", label="Buckets: multi-scale parities")
    plt.xlabel("K (refinement depth)")
    plt.ylabel("Number of observed endpoint buckets")
    plt.title("Endpoint partition growth (Process A sampling)")
    plt.legend()
    plt.tight_layout()

    # Save (names match LaTeX)
    fig.savefig("fig_endpoint_buckets.pdf", bbox_inches="tight")
    fig.savefig("fig_endpoint_buckets.png", dpi=300, bbox_inches="tight")
    plt.close(fig)


if __name__ == "__main__":
    main()
