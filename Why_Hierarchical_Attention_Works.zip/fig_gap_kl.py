"""fig_gap_kl.py

Estimated KL_clip(EPS) fiber-gap proxy (bucket-extrema) for Process A and Process B.

Important:
  - Process B yields Bernoulli probabilities in {0,1}, so strict KL can be infinite.
  - This script reports a *declared* smoothed readout KL_clip(EPS) via clipping.

Index convention (matches the revised paper):
  A history is x = (x_0, ..., x_{T-1}). Python negative indices follow
  x[-d] == x_{T-d}.

Outputs:
  - fig_gap_kl.pdf
  - fig_gap_kl.png
"""

import numpy as np
import matplotlib.pyplot as plt


# Sentinel for missing anchors (corresponds to \bot in the paper).
# Histories take values in {0,1}, so BOT=-1 is outside the token alphabet.
BOT = -1


EPS = 1e-12


# ----------------------------- Distances -----------------------------

def kl_eps_bernoulli(p: float, q: float) -> float:
    """KL_clip(EPS)(Bern(p) || Bern(q)) with EPS-clipping for finite readout."""
    p = float(np.clip(p, EPS, 1 - EPS))
    q = float(np.clip(q, EPS, 1 - EPS))
    return p * np.log(p / q) + (1 - p) * np.log((1 - p) / (1 - q))


def sym_kl_eps_bernoulli(p: float, q: float) -> float:
    """Symmetrized KL_clip(EPS) used by the bucket-extrema proxy: max(KL_clip(EPS)(p||q), KL_clip(EPS)(q||p))."""
    return max(kl_eps_bernoulli(p, q), kl_eps_bernoulli(q, p))


# ----------------------------- Toy Processes --------------------------

def process_A_next_p(
    x: np.ndarray,
    big_block: int = 64,
    base: float = 0.25,
    alpha: float = 0.5,
) -> float:
    """Process A: p(x_{T} = 1 | history) in {0.25, 0.75} via a parity feature (amplitude parameter alpha)."""
    m = min(len(x), big_block)
    z = int(np.sum(x[-m:]) % 2)
    return base + alpha * z


def process_B_next_p(x: np.ndarray, lag_star: int = 128) -> float:
    """Process B: p(x_{T}=1|history) is (deterministic) x_{T-lag_star}."""
    if len(x) >= lag_star:
        return float(x[-lag_star])
    return 0.0


# ----------------------------- Endpoints -----------------------------

def end_local_window(x: np.ndarray, w: int):
    w_eff = min(len(x), w)
    return tuple(x[-w_eff:].tolist())


def end_local_plus_exp_anchors(x: np.ndarray, w: int, K: int):
    e = [end_local_window(x, w)]
    for j in range(K):
        d = w * (2**j)
        e.append(int(x[-d]) if len(x) >= d else BOT)
    return tuple(e)


def end_local_plus_multiscale_parities(x: np.ndarray, w: int, K: int):
    e = [end_local_window(x, w)]
    for j in range(K):
        s = w * (2**j)
        m = min(len(x), s)
        parity = int(np.sum(x[-m:]) % 2)
        e.append(parity)
    return tuple(e)


# ----------------------------- Gap Estimation -------------------------

def estimate_gap_kl_eps_hat_binary(process_label_fn, endpoint_fn, T: int, n_hist: int, seed: int, kl_const: float) -> float:
    """\hat{Gap}_{KL,EPS,N} specialized to binary-valued processes.

    In this toy setup, each process produces only two possible Bernoulli parameters.
    Therefore, the bucket-extrema KL_clip(EPS) proxy is either 0 (pure buckets) or
    kl_const (a mixed bucket exists). We detect mixing via a 2-bit mask per bucket.
    """
    rng = np.random.default_rng(seed)
    X = rng.integers(0, 2, size=(n_hist, T), dtype=np.int8)

    seen = {}  # endpoint -> bitmask over labels {0,1}
    for i in range(n_hist):
        x = X[i]
        e = endpoint_fn(x)
        z = int(process_label_fn(x))  # z in {0,1}
        seen[e] = seen.get(e, 0) | (1 << z)

    return kl_const if any(mask == 3 for mask in seen.values()) else 0.0


# ----------------------------- Main ----------------------------------

def main():
    # Parameters (kept consistent across scripts)
    T = 256
    n_hist = 20000
    w = 16
    Ks = list(range(0, 7))

    # Constants for mapping labels -> Bernoulli parameters
    # Process A: p in {0.25, 0.75}
    pA0, pA1 = 0.25, 0.75
    KL_A = sym_kl_eps_bernoulli(pA0, pA1)
    # Process B: p in {0, 1} (after smoothing for KL_clip(EPS))
    pB0, pB1 = 0.0, 1.0
    KL_B = sym_kl_eps_bernoulli(pB0, pB1)

    # Process A curves (binary label = parity feature)
    A_kl_exp, A_kl_par = [], []
    for K in Ks:
        A_kl_exp.append(
            estimate_gap_kl_eps_hat_binary(
                process_label_fn=lambda x: int(np.sum(x[-min(len(x), 64):]) % 2),
                endpoint_fn=lambda x, w=w, K=K: end_local_plus_exp_anchors(x, w, K),
                T=T, n_hist=n_hist, seed=10 + K,
                kl_const=KL_A,
            )
        )
        A_kl_par.append(
            estimate_gap_kl_eps_hat_binary(
                process_label_fn=lambda x: int(np.sum(x[-min(len(x), 64):]) % 2),
                endpoint_fn=lambda x, w=w, K=K: end_local_plus_multiscale_parities(x, w, K),
                T=T, n_hist=n_hist, seed=110 + K,
                kl_const=KL_A,
            )
        )

    # Process B curves (binary label = anchor bit at lag_star, with default 0)
    lag_star = 128
    B_kl_exp, B_kl_par = [], []
    for K in Ks:
        B_kl_exp.append(
            estimate_gap_kl_eps_hat_binary(
                process_label_fn=lambda x, lag_star=lag_star: (int(x[-lag_star]) if len(x) >= lag_star else 0),
                endpoint_fn=lambda x, w=w, K=K: end_local_plus_exp_anchors(x, w, K),
                T=T, n_hist=n_hist, seed=210 + K,
                kl_const=KL_B,
            )
        )
        B_kl_par.append(
            estimate_gap_kl_eps_hat_binary(
                process_label_fn=lambda x, lag_star=lag_star: (int(x[-lag_star]) if len(x) >= lag_star else 0),
                endpoint_fn=lambda x, w=w, K=K: end_local_plus_multiscale_parities(x, w, K),
                T=T, n_hist=n_hist, seed=310 + K,
                kl_const=KL_B,
            )
        )

    # Plot
    fig = plt.figure()
    plt.plot(Ks, A_kl_exp, marker="o", label="Process A: local + exponential anchors")
    plt.plot(Ks, A_kl_par, marker="o", label="Process A: local + multi-scale parities")
    plt.plot(Ks, B_kl_exp, marker="o", label="Process B: local + exponential anchors")
    plt.plot(Ks, B_kl_par, marker="o", label="Process B: local + multi-scale parities")
    plt.xlabel("K (refinement depth)")
    plt.ylabel(r"Estimated $\widehat{\mathrm{Gap}}_{\mathrm{KL,clip(EPS)},N}$")
    plt.title("Global fiber-gap proxy in $\mathrm{KL}_{\mathrm{clip(EPS)}}$ (no training)")
    plt.legend()
    plt.tight_layout()

    # Save (names match LaTeX)
    fig.savefig("fig_gap_kl.pdf", bbox_inches="tight")
    fig.savefig("fig_gap_kl.png", dpi=300, bbox_inches="tight")
    plt.close(fig)


if __name__ == "__main__":
    main()
