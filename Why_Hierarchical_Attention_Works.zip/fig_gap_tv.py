"""fig_gap_tv.py

Estimated TV fiber-gap proxy (bucket-extrema) for Process A and Process B.

Index convention (matches the revised paper):
  A history is x = (x_0, ..., x_{T-1}). Python negative indices follow
  x[-d] == x_{T-d}.

Outputs:
  - fig_gap_tv.pdf
  - fig_gap_tv.png
"""

import numpy as np
import matplotlib.pyplot as plt


# Sentinel for missing anchors (corresponds to \bot in the paper).
# Histories take values in {0,1}, so BOT=-1 is outside the token alphabet.
BOT = -1


# ----------------------------- Distances -----------------------------

def tv_bernoulli(p: float, q: float) -> float:
    """Total variation distance between Bernoulli(p) and Bernoulli(q)."""
    return abs(p - q)


# ----------------------------- Toy Processes --------------------------

def process_A_next_p(
    x: np.ndarray,
    big_block: int = 64,
    base: float = 0.25,
    alpha: float = 0.5,
) -> float:
    """Process A: p(x_{T} = 1 | history) in {0.25, 0.75} via a parity feature (amplitude parameter alpha)."""
    m = min(len(x), big_block)
    z = int(np.sum(x[-m:]) % 2)
    return base + alpha * z


def process_B_next_p(x: np.ndarray, lag_star: int = 128) -> float:
    """Process B: p(x_{T}=1|history) is (deterministic) x_{T-lag_star}."""
    if len(x) >= lag_star:
        return float(x[-lag_star])
    return 0.0


# ----------------------------- Endpoints -----------------------------

def end_local_window(x: np.ndarray, w: int):
    w_eff = min(len(x), w)
    return tuple(x[-w_eff:].tolist())


def end_local_plus_exp_anchors(x: np.ndarray, w: int, K: int):
    e = [end_local_window(x, w)]
    for j in range(K):
        d = w * (2**j)
        e.append(int(x[-d]) if len(x) >= d else BOT)
    return tuple(e)


def end_local_plus_multiscale_parities(x: np.ndarray, w: int, K: int):
    e = [end_local_window(x, w)]
    for j in range(K):
        s = w * (2**j)
        m = min(len(x), s)
        parity = int(np.sum(x[-m:]) % 2)
        e.append(parity)
    return tuple(e)


# ----------------------------- Gap Estimation -------------------------

def estimate_gap_tv_hat(process_next_p, endpoint_fn, T: int, n_hist: int, seed: int) -> float:
    """\hat{Gap}_{TV,N}: bucket histories by endpoint and take max |p_max - p_min|."""
    rng = np.random.default_rng(seed)
    X = rng.integers(0, 2, size=(n_hist, T), dtype=np.int8)

    stats = {}  # endpoint -> [min_p, max_p]
    for i in range(n_hist):
        x = X[i]
        e = endpoint_fn(x)
        p = float(process_next_p(x))
        if e not in stats:
            stats[e] = [p, p]
        else:
            if p < stats[e][0]:
                stats[e][0] = p
            if p > stats[e][1]:
                stats[e][1] = p

    gap_tv = 0.0
    for pmin, pmax in stats.values():
        gap_tv = max(gap_tv, tv_bernoulli(pmin, pmax))
    return gap_tv


# ----------------------------- Main ----------------------------------

def main():
    # Parameters (kept consistent across scripts)
    T = 256
    n_hist = 20000
    w = 16
    Ks = list(range(0, 7))

    # Process A curves
    A_tv_exp, A_tv_par = [], []
    for K in Ks:
        A_tv_exp.append(
            estimate_gap_tv_hat(
                process_next_p=lambda x: process_A_next_p(x, big_block=64, base=0.25, alpha=0.5),
                endpoint_fn=lambda x, w=w, K=K: end_local_plus_exp_anchors(x, w, K),
                T=T,
                n_hist=n_hist,
                seed=10 + K,
            )
        )
        A_tv_par.append(
            estimate_gap_tv_hat(
                process_next_p=lambda x: process_A_next_p(x, big_block=64, base=0.25, alpha=0.5),
                endpoint_fn=lambda x, w=w, K=K: end_local_plus_multiscale_parities(x, w, K),
                T=T,
                n_hist=n_hist,
                seed=110 + K,
            )
        )

    # Process B curves
    lag_star = 128
    B_tv_exp, B_tv_par = [], []
    for K in Ks:
        B_tv_exp.append(
            estimate_gap_tv_hat(
                process_next_p=lambda x, lag_star=lag_star: process_B_next_p(x, lag_star=lag_star),
                endpoint_fn=lambda x, w=w, K=K: end_local_plus_exp_anchors(x, w, K),
                T=T,
                n_hist=n_hist,
                seed=210 + K,
            )
        )
        B_tv_par.append(
            estimate_gap_tv_hat(
                process_next_p=lambda x, lag_star=lag_star: process_B_next_p(x, lag_star=lag_star),
                endpoint_fn=lambda x, w=w, K=K: end_local_plus_multiscale_parities(x, w, K),
                T=T,
                n_hist=n_hist,
                seed=310 + K,
            )
        )

    # Plot
    fig = plt.figure()
    plt.plot(Ks, A_tv_exp, marker="o", label="Process A: local + exponential anchors")
    plt.plot(Ks, A_tv_par, marker="o", label="Process A: local + multi-scale parities")
    plt.plot(Ks, B_tv_exp, marker="o", label="Process B: local + exponential anchors")
    plt.plot(Ks, B_tv_par, marker="o", label="Process B: local + multi-scale parities")
    plt.xlabel("K (refinement depth)")
    plt.ylabel(r"Estimated $\widehat{\mathrm{Gap}}_{\mathrm{TV},N}$")
    plt.title("Global fiber-gap proxy in total variation (no training)")
    plt.legend()
    plt.tight_layout()

    # Save (names match LaTeX)
    fig.savefig("fig_gap_tv.pdf", bbox_inches="tight")
    fig.savefig("fig_gap_tv.png", dpi=300, bbox_inches="tight")
    plt.close(fig)


if __name__ == "__main__":
    main()
